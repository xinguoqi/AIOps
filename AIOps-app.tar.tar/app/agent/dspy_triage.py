import os
import json
import logging
from app.observability.tracer import observe as traceable

logger = logging.getLogger(__name__)

_dspy_configured = False


def _configure_dspy():
    global _dspy_configured
    if _dspy_configured:
        return
    import dspy
    lm = dspy.LM(
        model=f"openai/{os.getenv('QWEN_MODEL', 'qwen3-max-2026-01-23')}",
        api_key=os.getenv("DASHSCOPE_API_KEY", ""),
        api_base="https://dashscope.aliyuncs.com/compatible-mode/v1",
        temperature=0.2,
        max_tokens=1024,
    )
    dspy.configure(lm=lm)
    _dspy_configured = True


import dspy


class TriageSignature(dspy.Signature):
    """You are an expert IT operations analyst. Analyze the ticket using historical cases as reference.
    Return structured triage fields. category must be one of: password_reset, access_issue,
    system_error, performance, network, security, other. severity must be one of: low, medium,
    high, critical. action_type must be one of: informational, config_change, data_modification,
    service_restart, password_reset, other."""

    ticket_id: str = dspy.InputField(desc="Ticket identifier")
    title: str = dspy.InputField(desc="Ticket title")
    description: str = dspy.InputField(desc="Ticket description")
    priority: str = dspy.InputField(desc="Ticket priority")
    similar_cases: str = dspy.InputField(desc="Similar resolved historical tickets for reference")

    category: str = dspy.OutputField(desc="Issue category")
    severity: str = dspy.OutputField(desc="Severity level")
    root_cause_hypothesis: str = dspy.OutputField(desc="Concise root cause hypothesis")
    recommended_actions: str = dspy.OutputField(desc="JSON array of recommended action strings")
    requires_approval: str = dspy.OutputField(desc="true or false — true if severity is critical or action involves data modification")
    action_type: str = dspy.OutputField(desc="Action type classification")


class DSPyTriageModule(dspy.Module):
    def __init__(self):
        super().__init__()
        self.triage = dspy.ChainOfThought(TriageSignature)

    def forward(self, ticket_id, title, description, priority, similar_cases):
        return self.triage(
            ticket_id=ticket_id,
            title=title,
            description=description,
            priority=priority,
            similar_cases=similar_cases,
        )


_module = None


def get_module() -> DSPyTriageModule:
    global _module
    if _module is None:
        _configure_dspy()
        _module = DSPyTriageModule()
    return _module


@traceable(name="llm_triage")
def run_triage(ticket_id: str, title: str, description: str, priority: str,
               similar_cases: str) -> tuple[dict, int]:
    """Run DSPy triage. Returns (triage_dict, latency_ms)."""
    import time
    _configure_dspy()
    module = get_module()
    t0 = time.time()
    pred = module(
        ticket_id=ticket_id,
        title=title,
        description=description,
        priority=priority,
        similar_cases=similar_cases,
    )
    latency_ms = int((time.time() - t0) * 1000)

    try:
        actions = json.loads(pred.recommended_actions)
    except Exception:
        actions = [pred.recommended_actions]

    requires_approval = str(pred.requires_approval).lower() in ("true", "yes", "1")

    result = {
        "category": pred.category.strip(),
        "severity": pred.severity.strip(),
        "root_cause_hypothesis": pred.root_cause_hypothesis.strip(),
        "recommended_actions": actions,
        "requires_approval": requires_approval,
        "action_type": pred.action_type.strip(),
    }
    return result, latency_ms
