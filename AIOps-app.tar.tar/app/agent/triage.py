import json
import logging
import re
from app.agent.llm import llm_service
from app.jira.mock_store import jira_store
from app.audit.service import audit_service
from app.config import load_config
from app.observability.tracer import observe as traceable

logger = logging.getLogger(__name__)


def _fetch_attachments(ticket: dict, cfg: dict) -> str:
    attachments = ticket.get("attachments", [])
    if not attachments:
        return ""
    if not cfg.get("jira", {}).get("enabled", False):
        return ""
    try:
        from app.jira.client import JiraClient
        client = JiraClient(
            base_url=cfg["jira"]["url"],
            auth_type=cfg["jira"].get("auth_type", "pat"),
        )
    except Exception as e:
        logger.warning("Could not create Jira client for attachments: %s", e)
        return ""
    parts = []
    for att in attachments:
        if not att.get("readable"):
            continue
        text = att.get("text_content") or client.fetch_attachment_text(att)
        if text:
            att["text_content"] = text
            parts.append(f"--- Attachment: {att['filename']} ---\n{text}")
    return "\n\n".join(parts)


@traceable(name="triage_pipeline")
def triage_ticket(ticket_id: str, actor: str = "agent", force: bool = False) -> dict:
    ticket = jira_store.get(ticket_id)
    if not ticket:
        return {"error": f"Ticket {ticket_id} not found"}

    if not force and (ticket.get("_already_triaged") or ticket.get("triage")):
        logger.info("Skipping triage for %s — already triaged", ticket_id)
        return {"ticket_id": ticket_id, "skipped": True}

    cfg = load_config()
    prompt_version = cfg["agent"].get("prompt_version", "v1")
    attachment_text = _fetch_attachments(ticket, cfg)

    from app.rag.store import search as rag_search
    query = f"{ticket['title']} {ticket['description']}"
    similar_cases = rag_search(query, top_k=3)

    try:
        from app.agent.dspy_triage import run_triage
        triage, latency_ms = run_triage(
            ticket_id=ticket["id"],
            title=ticket["title"],
            description=ticket["description"] + (f"\n\nAttachments:\n{attachment_text}" if attachment_text else ""),
            priority=ticket["priority"],
            similar_cases=similar_cases,
        )
    except Exception as e:
        logger.error("DSPy triage failed for %s: %s", ticket_id, e)
        audit_service.log(actor=actor, action="triage_error", ticket_id=ticket_id,
                          detail=str(e), outcome="error", prompt_version=prompt_version)
        return {"error": str(e)}

    jira_store.set_triage(ticket_id, triage)
    comment = _format_comment(triage)
    jira_store.add_comment(ticket_id, comment, author="AIOps Agent")

    cfg2 = load_config()
    if cfg2.get("jira", {}).get("enabled", False):
        try:
            from app.jira.client import JiraClient
            client = JiraClient(
                base_url=cfg2["jira"]["url"],
                auth_type=cfg2["jira"].get("auth_type", "pat"),
            )
            client.add_comment(ticket_id, comment)
            client.transition_issue(ticket_id, "In Progress")
            client.update_labels(ticket_id, add=["TRIAGED"])
        except Exception as e:
            logger.warning("Could not write triage result to Jira for %s: %s", ticket_id, e)

    audit_service.log(
        actor=actor,
        action="triage_complete",
        ticket_id=ticket_id,
        detail=json.dumps({"latency_ms": latency_ms, "severity": triage.get("severity"),
                           "category": triage.get("category")}),
        outcome="success",
        prompt_version=prompt_version,
    )

    if triage.get("requires_approval"):
        _create_approval(ticket_id, triage, actor)

    return {"ticket_id": ticket_id, "triage": triage, "latency_ms": latency_ms}


def _parse_json(text: str):
    text = re.sub(r"```(?:json)?", "", text).strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        match = re.search(r"\{.*\}", text, re.DOTALL)
        if match:
            try:
                return json.loads(match.group())
            except Exception:
                pass
    return None


def _format_comment(triage: dict) -> str:
    actions = "\n".join(f"  - {a}" for a in triage.get("recommended_actions", []))
    return (
        f"**[AIOps Triage Result]**\n"
        f"- Category: {triage.get('category')}\n"
        f"- Severity: {triage.get('severity')}\n"
        f"- Root Cause Hypothesis: {triage.get('root_cause_hypothesis')}\n"
        f"- Recommended Actions:\n{actions}\n"
        f"- Requires Approval: {triage.get('requires_approval')}"
    )


def _create_approval(ticket_id: str, triage: dict, actor: str):
    from app.models import db, ApprovalRequest
    req = ApprovalRequest(
        ticket_id=ticket_id,
        action_type=triage.get("action_type", "other"),
        action_detail=json.dumps(triage.get("recommended_actions", [])),
        status="PENDING_APPROVAL",
    )
    db.session.add(req)
    db.session.commit()
    audit_service.log(actor=actor, action="approval_requested", ticket_id=ticket_id,
                      detail=f"action_type={triage.get('action_type')}")
