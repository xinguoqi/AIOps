import os
import logging

logger = logging.getLogger(__name__)


def is_tracing_enabled() -> bool:
    return os.getenv("OBSERVABILITY_ENABLED", "false").lower() == "true"


def observe(name: str = None):
    """
    Decorator factory. When OBSERVABILITY_ENABLED=true and langfuse is installed,
    wraps the function with langfuse.decorators.observe. Otherwise returns the function unchanged.
    """
    def decorator(fn):
        if not is_tracing_enabled():
            return fn
        try:
            from langfuse.decorators import observe as lf_observe
            return lf_observe(name=name or fn.__name__)(fn)
        except ImportError:
            logger.warning("langfuse not installed — tracing disabled")
            return fn
    return decorator
