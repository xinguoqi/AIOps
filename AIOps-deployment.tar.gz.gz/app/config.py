import os
import yaml
from dotenv import load_dotenv

load_dotenv()

def load_config():
    with open("config.yaml", "r") as f:
        return yaml.safe_load(f)

def save_config(cfg: dict):
    with open("config.yaml", "w") as f:
        yaml.dump(cfg, f, default_flow_style=False)

class AppConfig:
    SECRET_KEY = os.getenv("SECRET_KEY", "dev-secret-key")
    QWEN_MODEL = os.getenv("QWEN_MODEL", "qwen3-max-2026-01-23")
    SQLALCHEMY_DATABASE_URI = "sqlite:///aiops.db"
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    DASHSCOPE_API_KEY = os.getenv("DASHSCOPE_API_KEY", "")
