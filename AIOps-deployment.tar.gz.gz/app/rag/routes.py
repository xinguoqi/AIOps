import os
from flask import Blueprint, render_template, request, flash, redirect, url_for, jsonify
from flask_login import login_required
from app.auth.decorators import role_required
from werkzeug.utils import secure_filename

rag_bp = Blueprint("rag", __name__)

ALLOWED_EXTENSIONS = {"xlsx", "csv", "txt"}
UPLOAD_FOLDER = "instance/uploads"


def _allowed(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


@rag_bp.route("/knowledge-base")
@login_required
@role_required("operator")
def knowledge_base():
    from app.rag.store import collection_stats
    stats = collection_stats()
    return render_template("knowledge_base.html", stats=stats)


@rag_bp.route("/knowledge-base/upload", methods=["POST"])
@login_required
@role_required("operator")
def upload_file():
    from app.rag.store import index_excel
    f = request.files.get("file")
    if not f or not f.filename:
        flash("No file selected.", "warning")
        return redirect(url_for("rag.knowledge_base"))
    if not _allowed(f.filename):
        flash("Only .xlsx, .csv, .txt files are supported.", "warning")
        return redirect(url_for("rag.knowledge_base"))
    os.makedirs(UPLOAD_FOLDER, exist_ok=True)
    filename = secure_filename(f.filename)
    save_path = os.path.join(UPLOAD_FOLDER, filename)
    f.save(save_path)
    try:
        count = index_excel(save_path, source_name=filename)
        flash(f"Indexed {count} records from {filename}.", "success")
    except Exception as e:
        flash(f"Failed to index file: {e}", "danger")
    return redirect(url_for("rag.knowledge_base"))


@rag_bp.route("/knowledge-base/index-default", methods=["POST"])
@login_required
@role_required("operator")
def index_default():
    from app.rag.store import index_excel
    path = "data/History tickets sample for AIOPS.xlsx"
    if not os.path.exists(path):
        flash("Default file not found.", "danger")
        return redirect(url_for("rag.knowledge_base"))
    try:
        count = index_excel(path, source_name="History tickets sample for AIOPS.xlsx")
        flash(f"Indexed {count} records from default file.", "success")
    except Exception as e:
        flash(f"Failed to index default file: {e}", "danger")
    return redirect(url_for("rag.knowledge_base"))


@rag_bp.route("/api/rag/stats")
@login_required
def rag_stats():
    from app.rag.store import collection_stats
    return jsonify(collection_stats())
