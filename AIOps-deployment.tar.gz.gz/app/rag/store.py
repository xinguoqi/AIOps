import os
import logging
from pathlib import Path

logger = logging.getLogger(__name__)

_client = None
_collection = None
COLLECTION_NAME = "aiops_knowledge"
CHROMA_DIR = "instance/chroma"


def _reset_collection_cache():
    global _client, _collection
    _client = None
    _collection = None


def _get_collection():
    global _client, _collection
    if _collection is not None:
        return _collection
    import chromadb
    from chromadb.utils.embedding_functions import EmbeddingFunction

    class DashScopeEmbedding(EmbeddingFunction):
        BATCH_SIZE = 10  # DashScope text-embedding-v3 limit

        def __call__(self, input):
            import requests
            api_key = os.getenv("DASHSCOPE_API_KEY", "")
            all_embeddings = []
            for i in range(0, len(input), self.BATCH_SIZE):
                batch = input[i:i + self.BATCH_SIZE]
                resp = requests.post(
                    "https://dashscope.aliyuncs.com/compatible-mode/v1/embeddings",
                    headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
                    json={"model": "text-embedding-v3", "input": batch},
                    timeout=30,
                )
                resp.raise_for_status()
                data = resp.json()["data"]
                all_embeddings.extend(
                    item["embedding"] for item in sorted(data, key=lambda x: x["index"])
                )
            return all_embeddings

    os.makedirs(CHROMA_DIR, exist_ok=True)
    _client = chromadb.PersistentClient(path=CHROMA_DIR)
    _collection = _client.get_or_create_collection(
        name=COLLECTION_NAME,
        embedding_function=DashScopeEmbedding(),
        metadata={"hnsw:space": "cosine"},
    )
    return _collection


def index_excel(file_path: str, source_name: str = None) -> int:
    """Index rows from an Excel file. Returns number of rows indexed."""
    import openpyxl
    wb = openpyxl.load_workbook(file_path)
    ws = wb.active
    headers = [cell.value for cell in ws[1]]
    col = _get_collection()
    docs, ids, metas = [], [], []
    for i, row in enumerate(ws.iter_rows(min_row=2, values_only=True)):
        row_dict = dict(zip(headers, row))
        text = " | ".join(f"{k}: {v}" for k, v in row_dict.items() if v)
        if not text.strip():
            continue
        doc_id = f"{source_name or Path(file_path).stem}_{i}"
        docs.append(text)
        ids.append(doc_id)
        metas.append({"source": source_name or Path(file_path).name, "row": i})
    if docs:
        col.upsert(documents=docs, ids=ids, metadatas=metas)
    logger.info("Indexed %d rows from %s", len(docs), file_path)
    return len(docs)


def search(query: str, top_k: int = 3) -> str:
    """Return formatted similar cases string for RAG context."""
    col = _get_collection()
    if col.count() == 0:
        return "No historical cases available."
    results = col.query(query_texts=[query], n_results=min(top_k, col.count()))
    docs = results.get("documents", [[]])[0]
    if not docs:
        return "No similar cases found."
    lines = [f"Case {i+1}: {doc}" for i, doc in enumerate(docs)]
    return "\n".join(lines)


def collection_stats() -> dict:
    """Return stats about the knowledge base."""
    try:
        col = _get_collection()
        count = col.count()
        sources = {}
        if count > 0:
            all_meta = col.get(include=["metadatas"])["metadatas"]
            for m in all_meta:
                src = m.get("source", "unknown")
                sources[src] = sources.get(src, 0) + 1
        return {"total": count, "sources": sources}
    except Exception as e:
        logger.warning("Could not get collection stats: %s", e)
        return {"total": 0, "sources": {}}
