from app.models import db, AuditLog
from datetime import datetime

class AuditService:
    def log(self, actor, action, ticket_id=None, detail=None, outcome="success", prompt_version=None):
        entry = AuditLog(
            actor=actor,
            action=action,
            ticket_id=ticket_id,
            detail=detail,
            outcome=outcome,
            prompt_version=prompt_version,
            timestamp=datetime.utcnow(),
        )
        db.session.add(entry)
        db.session.commit()

    def query(self, actor=None, ticket_id=None, limit=200):
        q = AuditLog.query.order_by(AuditLog.timestamp.desc())
        if actor:
            q = q.filter_by(actor=actor)
        if ticket_id:
            q = q.filter_by(ticket_id=ticket_id)
        return q.limit(limit).all()

audit_service = AuditService()
