from flask import Blueprint, jsonify, request
from flask_login import login_required, current_user
from app.auth.decorators import role_required
from app.models import db, ApprovalRequest, AuditLog
from app.jira.mock_store import jira_store
from app.audit.service import audit_service
from datetime import datetime

api_bp = Blueprint("api", __name__, url_prefix="/api")

@api_bp.route("/health")
def health():
    from app.models import db
    try:
        db.session.execute(db.text("SELECT 1"))
        db_ok = True
    except Exception:
        db_ok = False
    return jsonify({"status": "ok" if db_ok else "degraded", "db": db_ok})

@api_bp.route("/triage/<ticket_id>", methods=["POST"])
@login_required
@role_required("operator")
def trigger_triage(ticket_id):
    from app.agent.triage import triage_ticket
    data = request.get_json(silent=True) or {}
    force = bool(data.get("force", False))
    result = triage_ticket(ticket_id, actor=current_user.username, force=force)
    if "error" in result:
        return jsonify(result), 400
    return jsonify(result)

@api_bp.route("/approvals/<int:approval_id>/decide", methods=["POST"])
@login_required
@role_required("operator")
def decide_approval(approval_id):
    data = request.get_json(force=True)
    decision = data.get("decision")  # APPROVED or REJECTED
    reason = data.get("reason", "")
    if decision not in ("APPROVED", "REJECTED"):
        return jsonify({"error": "decision must be APPROVED or REJECTED"}), 400

    approval = ApprovalRequest.query.get_or_404(approval_id)
    if approval.status != "PENDING_APPROVAL":
        return jsonify({"error": "Already decided"}), 409

    # Admin required for critical approvals
    ticket = jira_store.get(approval.ticket_id)
    if ticket and ticket.get("triage", {}) and ticket["triage"].get("severity") == "critical":
        if current_user.role != "admin":
            return jsonify({"error": "Admin required for critical approvals"}), 403

    approval.status = decision
    approval.decided_at = datetime.utcnow()
    approval.decided_by = current_user.username
    approval.reason = reason
    db.session.commit()

    if decision == "APPROVED":
        from app.agent.executor import execute_action
        execute_action(approval, actor=current_user.username)

    audit_service.log(
        actor=current_user.username,
        action=f"approval_{decision.lower()}",
        ticket_id=approval.ticket_id,
        detail=f"Approval #{approval_id}: {reason}",
        outcome=decision.lower(),
    )
    return jsonify({"status": decision})

@api_bp.route("/audit")
@login_required
@role_required("operator")
def get_audit():
    actor = request.args.get("actor")
    ticket_id = request.args.get("ticket_id")
    logs = audit_service.query(actor=actor, ticket_id=ticket_id)
    return jsonify([{
        "id": l.id,
        "timestamp": l.timestamp.isoformat(),
        "actor": l.actor,
        "action": l.action,
        "ticket_id": l.ticket_id,
        "detail": l.detail,
        "outcome": l.outcome,
        "prompt_version": l.prompt_version,
    } for l in logs])

@api_bp.route("/config", methods=["POST"])
@login_required
@role_required("admin")
def update_config():
    from app.config import load_config, save_config
    data = request.get_json(force=True)
    cfg = load_config()
    # Only allow safe keys
    if "llm" in data:
        cfg["llm"].update({k: v for k, v in data["llm"].items() if k in ("model", "temperature", "max_tokens")})
    if "agent" in data:
        cfg["agent"].update({k: v for k, v in data["agent"].items() if k in ("polling_interval_seconds", "enabled")})
    if "jira" in data:
        cfg.setdefault("jira", {}).update({
            k: v for k, v in data["jira"].items()
            if k in ("enabled", "url", "project_key", "auth_type", "poll_jql", "max_results")
        })
    save_config(cfg)
    audit_service.log(actor=current_user.username, action="config_update", detail=str(data))
    return jsonify({"status": "saved"})

@api_bp.route("/agent/toggle", methods=["POST"])
@login_required
@role_required("admin")
def toggle_agent():
    from app.config import load_config, save_config
    from app.agent.scheduler import pause_agent, resume_agent
    cfg = load_config()
    cfg["agent"]["enabled"] = not cfg["agent"].get("enabled", True)
    save_config(cfg)
    if cfg["agent"]["enabled"]:
        resume_agent()
    else:
        pause_agent()
    audit_service.log(actor=current_user.username, action="agent_toggle",
                      detail=f"enabled={cfg['agent']['enabled']}")
    return jsonify({"enabled": cfg["agent"]["enabled"]})

@api_bp.route("/metrics")
@login_required
def metrics():
    from app.jira.mock_store import jira_store
    from app.models import AuditLog
    from datetime import datetime, timedelta
    tickets = jira_store.get_all()
    total = len(tickets)
    triaged = sum(1 for t in tickets if t.get("triage"))
    pending = ApprovalRequest.query.filter_by(status="PENDING_APPROVAL").count()
    approved = ApprovalRequest.query.filter_by(status="APPROVED").count()
    rejected = ApprovalRequest.query.filter_by(status="REJECTED").count()
    # LLM latency from audit log detail
    llm_logs = AuditLog.query.filter_by(action="triage_complete").all()
    latencies = []
    for l in llm_logs:
        if l.detail and "latency_ms" in l.detail:
            try:
                import json
                d = json.loads(l.detail)
                latencies.append(d["latency_ms"])
            except Exception:
                pass
    p50 = sorted(latencies)[len(latencies)//2] if latencies else None
    p95 = sorted(latencies)[int(len(latencies)*0.95)] if latencies else None
    return jsonify({
        "total_tickets": total,
        "triaged": triaged,
        "pending_approvals": pending,
        "approved": approved,
        "rejected": rejected,
        "llm_latency_p50_ms": p50,
        "llm_latency_p95_ms": p95,
    })

@api_bp.route("/jira/sync", methods=["POST"])
@login_required
@role_required("operator")
def sync_jira():
    from app.config import load_config
    from app.jira.mock_store import jira_store
    cfg = load_config()
    jira_cfg = cfg.get("jira", {})
    if not jira_cfg.get("enabled"):
        return jsonify({"ok": False, "message": "Jira integration is not enabled"})
    try:
        from app.jira.client import JiraClient
        client = JiraClient(base_url=jira_cfg["url"], auth_type=jira_cfg.get("auth_type", "pat"))
        project_key = jira_cfg.get("project_key", "")
        jql = jira_cfg.get("poll_jql", "project={project_key} AND statusCategory != Done ORDER BY created DESC")
        jql = jql.format(project_key=project_key)
        tickets = client.search_issues(jql, max_results=jira_cfg.get("max_results", 50))
        for t in tickets:
            jira_store.upsert(t)

        # Auto-triage any NEW tickets that don't have a triage result yet
        from app.agent.triage import triage_ticket
        triaged = 0
        for t in tickets:
            if t["status"] == "NEW" and not jira_store.get(t["id"]).get("triage"):
                triage_ticket(t["id"], actor=current_user.username)
                triaged += 1

        audit_service.log(actor=current_user.username, action="jira_sync",
                          detail=f"synced {len(tickets)} tickets, triaged {triaged} via JQL: {jql}", outcome="success")
        return jsonify({"ok": True, "synced": len(tickets), "triaged": triaged})
    except Exception as e:
        return jsonify({"ok": False, "message": str(e)})

@api_bp.route("/jira/test", methods=["POST"])
@login_required
@role_required("admin")
def test_jira_connection():
    from app.config import load_config
    cfg = load_config()
    jira_cfg = cfg.get("jira", {})
    if not jira_cfg.get("url"):
        return jsonify({"ok": False, "message": "Jira URL not configured"})
    try:
        from app.jira.client import JiraClient
        client = JiraClient(base_url=jira_cfg["url"], auth_type=jira_cfg.get("auth_type", "pat"))
        # Hit the myself endpoint — works with both PAT and session auth
        resp = client._session.get(client._url("/myself"), timeout=10)
        if resp.status_code == 403:
            body = resp.json() if resp.content else {}
            msg = body.get("message", resp.text)
            if "Basic Authentication has been disabled" in msg:
                return jsonify({"ok": False, "message": "Basic auth is disabled on this Jira instance. Switch auth_type to 'pat' and set JIRA_PAT in .env."})
            return jsonify({"ok": False, "message": f"403 Forbidden: {msg}"})
        resp.raise_for_status()
        user = resp.json()
        # Also fetch server info for version
        info_resp = client._session.get(client._url("/serverInfo"), timeout=10)
        version = info_resp.json().get("version", "") if info_resp.ok else ""
        return jsonify({"ok": True, "message": f"Connected as {user.get('displayName', user.get('name', '?'))} — Jira {version}"})
    except Exception as e:
        return jsonify({"ok": False, "message": str(e)})
