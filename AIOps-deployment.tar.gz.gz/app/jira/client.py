import os
import logging
import requests
from requests.auth import HTTPBasicAuth

logger = logging.getLogger(__name__)

# Jira Server/DC field mappings
_PRIORITY_MAP = {
    "Blocker": "critical", "Critical": "critical",
    "Major": "high", "High": "high",
    "Medium": "medium", "Normal": "medium",
    "Minor": "low", "Low": "low", "Trivial": "low",
}

class JiraClient:
    """REST API v2 client for Jira Server / Data Center."""

    def __init__(self, base_url: str, auth_type: str = "pat"):
        self._base = base_url.rstrip("/")
        self._auth_type = auth_type
        self._session = requests.Session()
        self._session.headers.update({"Content-Type": "application/json", "Accept": "application/json"})
        self._configure_auth()

    def _configure_auth(self):
        if self._auth_type == "pat":
            token = os.getenv("JIRA_PAT", "")
            if not token:
                raise ValueError("JIRA_PAT env var not set")
            self._session.headers["Authorization"] = f"Bearer {token}"
        else:
            user = os.getenv("JIRA_USER", "")
            password = os.getenv("JIRA_PASSWORD", "")
            if not user or not password:
                raise ValueError("JIRA_USER and JIRA_PASSWORD env vars not set")
            self._session.auth = HTTPBasicAuth(user, password)

    def _url(self, path: str) -> str:
        return f"{self._base}/rest/api/2{path}"

    def search_issues(self, jql: str, max_results: int = 50) -> list[dict]:
        """Search issues by JQL, return normalized ticket dicts."""
        resp = self._session.get(
            self._url("/search"),
            params={"jql": jql, "maxResults": max_results,
                    "fields": "summary,description,priority,status,comment,issuetype,created,attachment,labels"},
            timeout=15,
        )
        resp.raise_for_status()
        return [self._normalize(issue) for issue in resp.json().get("issues", [])]

    def get_issue(self, issue_key: str) -> dict | None:
        resp = self._session.get(
            self._url(f"/issue/{issue_key}"),
            params={"fields": "summary,description,priority,status,comment,issuetype,created,attachment,labels"},
            timeout=15,
        )
        if resp.status_code == 404:
            return None
        resp.raise_for_status()
        return self._normalize(resp.json())

    def fetch_attachment_text(self, attachment: dict, max_bytes: int = 8192) -> str:
        """Download a text-readable attachment and return its content (truncated)."""
        url = attachment.get("content_url") or attachment.get("content", "")
        if not url:
            return ""
        try:
            resp = self._session.get(url, timeout=15, stream=True)
            resp.raise_for_status()
            content = b""
            for chunk in resp.iter_content(chunk_size=4096):
                content += chunk
                if len(content) >= max_bytes:
                    break
            return content[:max_bytes].decode("utf-8", errors="replace")
        except Exception as e:
            logger.warning("Could not fetch attachment %s: %s", url, e)
            return ""

    def add_comment(self, issue_key: str, body: str) -> dict:
        resp = self._session.post(
            self._url(f"/issue/{issue_key}/comment"),
            json={"body": body},
            timeout=15,
        )
        resp.raise_for_status()
        return resp.json()

    def update_labels(self, issue_key: str, add: list[str]) -> bool:
        """Add labels to an issue without removing existing ones."""
        resp = self._session.get(
            self._url(f"/issue/{issue_key}"),
            params={"fields": "labels"},
            timeout=15,
        )
        resp.raise_for_status()
        existing = list((resp.json().get("fields", {}).get("labels") or []))
        merged = list({*existing, *add})
        resp2 = self._session.put(
            self._url(f"/issue/{issue_key}"),
            json={"fields": {"labels": merged}},
            timeout=15,
        )
        resp2.raise_for_status()
        return True

    def transition_issue(self, issue_key: str, transition_name: str) -> bool:
        """Transition issue to a named status (e.g. 'In Progress', 'Resolved')."""
        # Get available transitions
        resp = self._session.get(self._url(f"/issue/{issue_key}/transitions"), timeout=15)
        resp.raise_for_status()
        transitions = resp.json().get("transitions", [])
        match = next((t for t in transitions if t["name"].lower() == transition_name.lower()), None)
        if not match:
            logger.warning("Transition '%s' not found for %s. Available: %s",
                           transition_name, issue_key, [t["name"] for t in transitions])
            return False
        resp2 = self._session.post(
            self._url(f"/issue/{issue_key}/transitions"),
            json={"transition": {"id": match["id"]}},
            timeout=15,
        )
        resp2.raise_for_status()
        return True

    def _normalize(self, issue: dict) -> dict:
        """Convert Jira issue to the internal ticket schema."""
        fields = issue.get("fields", {})
        priority_name = (fields.get("priority") or {}).get("name", "Medium")
        status_name = (fields.get("status") or {}).get("name", "Open")
        comments_raw = (fields.get("comment") or {}).get("comments", [])

        # Detect if AIOps has already posted a triage comment — prevents re-triage
        already_triaged = any(
            "[AIOps Triage Result]" in (c.get("body") or "")
            for c in comments_raw
        )

        # Readable attachment types
        _TEXT_MIME = ("text/", "application/json", "application/xml",
                      "application/x-sh", "application/x-log")
        attachments = [
            {
                "filename": a.get("filename", ""),
                "mime_type": a.get("mimeType", ""),
                "size": a.get("size", 0),
                "content_url": a.get("content", ""),
                "content": a.get("content", ""),  # alias used by fetch_attachment_text
                "readable": a.get("mimeType", "").startswith(_TEXT_MIME),
            }
            for a in (fields.get("attachment") or [])
        ]

        return {
            "id": issue["key"],
            "title": fields.get("summary", ""),
            "description": fields.get("description") or "",
            "priority": _PRIORITY_MAP.get(priority_name, "medium"),
            "status": self._map_status(status_name),
            "labels": list(fields.get("labels") or []),
            "category": "",
            "comments": [
                {
                    "author": (c.get("author") or {}).get("displayName", "unknown"),
                    "body": c.get("body", ""),
                    "timestamp": c.get("created", ""),
                }
                for c in comments_raw
            ],
            "triage": None,
            "created_at": fields.get("created", ""),
            "_jira_status": status_name,
            "_already_triaged": already_triaged,
            "attachments": attachments,
        }

    @staticmethod
    def _map_status(jira_status: str) -> str:
        s = jira_status.lower()
        if s in ("open", "to do", "new", "reopened", "backlog"):
            return "NEW"
        if s in ("in progress", "in review"):
            return "IN_PROGRESS"
        if s in ("resolved", "done", "closed"):
            return "RESOLVED"
        return "NEW"
