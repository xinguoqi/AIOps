from flask import Blueprint, jsonify, request
from flask_login import login_required
from app.jira.mock_store import jira_store

jira_bp = Blueprint("jira", __name__, url_prefix="/jira")

@jira_bp.route("/issues", methods=["GET"])
@login_required
def list_issues():
    status_filter = request.args.get("status")
    issues = jira_store.get_all(status_filter=status_filter)
    return jsonify(issues)

@jira_bp.route("/issues/<ticket_id>", methods=["GET"])
@login_required
def get_issue(ticket_id):
    ticket = jira_store.get(ticket_id)
    if not ticket:
        return jsonify({"error": "Not found"}), 404
    return jsonify(ticket)

@jira_bp.route("/issues", methods=["POST"])
@login_required
def create_issue():
    data = request.get_json(force=True)
    ticket = jira_store.create(data)
    return jsonify(ticket), 201

@jira_bp.route("/issues/<ticket_id>/comment", methods=["POST"])
@login_required
def add_comment(ticket_id):
    data = request.get_json(force=True)
    comment = data.get("body", "")
    author = data.get("author", "system")
    ticket = jira_store.add_comment(ticket_id, comment, author)
    if not ticket:
        return jsonify({"error": "Not found"}), 404
    return jsonify(ticket)
