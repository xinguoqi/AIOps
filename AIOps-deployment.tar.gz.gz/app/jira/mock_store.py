import json
import os
import uuid
from datetime import datetime
from threading import Lock

class MockJiraStore:
    def __init__(self, persist_path="data/mock_jira.json"):
        self._lock = Lock()
        self._path = persist_path
        self._tickets: dict = {}
        self._load()

    def _load(self):
        if os.path.exists(self._path):
            with open(self._path) as f:
                data = json.load(f)
            # Support both list (seed) and dict (persisted) formats
            if isinstance(data, list):
                self._tickets = {t["id"]: t for t in data}
            else:
                self._tickets = data

    def _save(self):
        os.makedirs(os.path.dirname(self._path), exist_ok=True)
        with open(self._path, "w") as f:
            json.dump(self._tickets, f, indent=2, default=str)

    def get_all(self, status_filter=None):
        with self._lock:
            tickets = list(self._tickets.values())
            if status_filter:
                tickets = [t for t in tickets if t["status"] == status_filter]
            return tickets

    def get(self, ticket_id):
        with self._lock:
            return self._tickets.get(ticket_id)

    def create(self, data: dict):
        with self._lock:
            ticket_id = data.get("id") or f"AIOPS-{str(uuid.uuid4())[:8].upper()}"
            ticket = {
                "id": ticket_id,
                "title": data.get("title", "Untitled"),
                "description": data.get("description", ""),
                "priority": data.get("priority", "medium"),
                "status": data.get("status", "NEW"),
                "category": data.get("category", ""),
                "comments": [],
                "triage": None,
                "created_at": datetime.utcnow().isoformat(),
            }
            self._tickets[ticket_id] = ticket
            self._save()
            return ticket

    def upsert(self, ticket: dict):
        """Insert or update a ticket from Jira.

        Rules:
        - Jira is the authoritative source for: status, title, description,
          priority, labels, attachments list.
        - Local-only fields preserved across syncs: triage result, cached
          attachment text content.
        - Comments are merged: Jira comments are canonical; local-only AIOps
          comments are kept only if Jira hasn't echoed them back yet.
        """
        with self._lock:
            existing = self._tickets.get(ticket["id"])
            if existing:
                # Jira status is authoritative — always use the incoming value.
                # Never let local code override it here.

                # Preserve local triage result (Jira doesn't store our triage JSON)
                ticket["triage"] = existing.get("triage")

                # Merge comments: keep local-only AIOps comments not yet in Jira.
                incoming_bodies = {c["body"] for c in ticket.get("comments", [])}
                incoming_has_triage = any(
                    "[AIOps Triage Result]" in b for b in incoming_bodies
                )
                local_extra = [
                    c for c in existing.get("comments", [])
                    if c["body"] not in incoming_bodies
                    and not (incoming_has_triage and "[AIOps Triage Result]" in c["body"])
                ]
                ticket["comments"] = ticket.get("comments", []) + local_extra

                # Preserve attachment text content already fetched
                existing_atts = {a["filename"]: a for a in existing.get("attachments", [])}
                for att in ticket.get("attachments", []):
                    if att["filename"] in existing_atts:
                        cached = existing_atts[att["filename"]]
                        att["text_content"] = cached.get("text_content", "")
                        if not att.get("content") and cached.get("content_url"):
                            att["content"] = cached["content_url"]
            self._tickets[ticket["id"]] = ticket
            self._save()

    def add_comment(self, ticket_id, body, author="system"):
        with self._lock:
            ticket = self._tickets.get(ticket_id)
            if not ticket:
                return None
            ticket["comments"].append({
                "author": author,
                "body": body,
                "timestamp": datetime.utcnow().isoformat(),
            })
            self._save()
            return ticket

    def set_triage(self, ticket_id, triage_data):
        with self._lock:
            ticket = self._tickets.get(ticket_id)
            if not ticket:
                return None
            ticket["triage"] = triage_data
            # Post-triage: advance status to IN_PROGRESS and mark with TRIAGED label.
            # This is an intentional AIOps action, not a sync override.
            ticket["status"] = "IN_PROGRESS"
            labels = ticket.setdefault("labels", [])
            if "TRIAGED" not in labels:
                labels.append("TRIAGED")
            self._save()
            return ticket

jira_store = MockJiraStore()
