from flask import Blueprint, render_template, redirect, url_for
from flask_login import login_required, current_user
from app.jira.mock_store import jira_store
from app.models import ApprovalRequest, AuditLog
from app.auth.decorators import role_required

main_bp = Blueprint("main", __name__)

@main_bp.route("/")
@login_required
def dashboard():
    tickets = jira_store.get_all()
    total = len(tickets)
    triaged = sum(1 for t in tickets if t.get("triage"))
    pending_approvals = ApprovalRequest.query.filter_by(status="PENDING_APPROVAL").count()
    recent_audit = AuditLog.query.order_by(AuditLog.timestamp.desc()).limit(5).all()
    return render_template("dashboard.html",
        total=total, triaged=triaged,
        pending_approvals=pending_approvals,
        recent_audit=recent_audit,
        tickets=tickets[:10])

@main_bp.route("/tickets")
@login_required
def tickets():
    all_tickets = jira_store.get_all()
    return render_template("tickets.html", tickets=all_tickets)

@main_bp.route("/approvals")
@login_required
@role_required("operator")
def approvals():
    pending = ApprovalRequest.query.filter_by(status="PENDING_APPROVAL").all()
    history = ApprovalRequest.query.filter(
        ApprovalRequest.status != "PENDING_APPROVAL"
    ).order_by(ApprovalRequest.decided_at.desc()).limit(20).all()
    return render_template("approvals.html", pending=pending, history=history)

@main_bp.route("/audit")
@login_required
@role_required("operator")
def audit():
    logs = AuditLog.query.order_by(AuditLog.timestamp.desc()).limit(200).all()
    return render_template("audit.html", logs=logs)

@main_bp.route("/config")
@login_required
@role_required("admin")
def config_page():
    from app.config import load_config
    cfg = load_config()
    return render_template("config.html", cfg=cfg)
