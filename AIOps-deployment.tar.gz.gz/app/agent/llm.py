import os
import json
import time
import logging
import requests
from flask import current_app

logger = logging.getLogger(__name__)

DASHSCOPE_URL = "https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions"

class LLMService:
    def __init__(self):
        self._api_key = None

    def _get_key(self):
        if self._api_key:
            return self._api_key
        self._api_key = os.getenv("DASHSCOPE_API_KEY", "")
        return self._api_key

    def chat(self, system_prompt: str, user_message: str, model: str = os.getenv("QWEN_MODEL", "qwen3-max-2026-01-23"),
             temperature: float = 0.2, max_tokens: int = 1024) -> tuple[str, int]:
        """Returns (response_text, latency_ms). Raises on error."""
        api_key = self._get_key()
        if not api_key:
            raise ValueError("DASHSCOPE_API_KEY not set")

        payload = {
            "model": model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_message},
            ],
            "temperature": temperature,
            "max_tokens": max_tokens,
        }
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        }
        t0 = time.time()
        resp = requests.post(DASHSCOPE_URL, json=payload, headers=headers, timeout=30)
        latency_ms = int((time.time() - t0) * 1000)
        resp.raise_for_status()
        content = resp.json()["choices"][0]["message"]["content"]
        return content, latency_ms

llm_service = LLMService()
