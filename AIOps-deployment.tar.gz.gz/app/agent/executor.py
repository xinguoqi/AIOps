import logging
from app.jira.mock_store import jira_store
from app.audit.service import audit_service

logger = logging.getLogger(__name__)

def execute_action(approval, actor: str = "system"):
    """Simulated action execution — logs the action and updates ticket status."""
    ticket_id = approval.ticket_id
    action_type = approval.action_type

    # Simulate action
    logger.info("Executing action '%s' for ticket %s by %s", action_type, ticket_id, actor)
    jira_store.update_status(ticket_id, "RESOLVED")
    jira_store.add_comment(
        ticket_id,
        f"**[AIOps Action Executed]** Action `{action_type}` approved by {actor} and executed successfully (simulated).",
        author="AIOps Agent",
    )
    audit_service.log(
        actor=actor,
        action="action_executed",
        ticket_id=ticket_id,
        detail=f"action_type={action_type}, approval_id={approval.id}",
        outcome="success",
    )
