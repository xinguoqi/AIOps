import logging
from apscheduler.schedulers.background import BackgroundScheduler

logger = logging.getLogger(__name__)
_scheduler = BackgroundScheduler()
_job = None

def _get_jira_client(cfg):
    """Return a JiraClient if real Jira is configured, else None."""
    jira_cfg = cfg.get("jira", {})
    if not jira_cfg.get("enabled", False):
        return None
    from app.jira.client import JiraClient
    return JiraClient(
        base_url=jira_cfg["url"],
        auth_type=jira_cfg.get("auth_type", "pat"),
    )

def _poll_and_triage(app):
    from app.config import load_config
    cfg = load_config()
    if not cfg["agent"].get("enabled", True):
        return
    with app.app_context():
        from app.jira.mock_store import jira_store
        from app.agent.triage import triage_ticket

        jira_cfg = cfg.get("jira", {})
        client = None

        # Sync from real Jira if enabled
        if jira_cfg.get("enabled", False):
            try:
                client = _get_jira_client(cfg)
                project_key = jira_cfg.get("project_key", "OPS")
                jql = jira_cfg.get("poll_jql", "project={project_key} AND status=Open ORDER BY created DESC")
                jql = jql.format(project_key=project_key)
                max_results = jira_cfg.get("max_results", 50)
                tickets = client.search_issues(jql, max_results=max_results)
                for ticket in tickets:
                    jira_store.upsert(ticket)
                logger.info("Synced %d issues from Jira", len(tickets))
            except Exception as e:
                logger.error("Jira sync failed: %s", e)
                client = None

        # Triage only tickets whose Jira status maps to NEW and have no triage yet
        new_tickets = jira_store.get_all(status_filter="NEW")
        for ticket in new_tickets:
            if ticket.get("triage") or ticket.get("_already_triaged"):
                continue
            logger.info("Auto-triaging ticket %s", ticket["id"])
            result = triage_ticket(ticket["id"], actor="agent")

            # Write triage comment back to real Jira, then transition + label
            if client and "error" not in result:
                try:
                    triage = result.get("triage", {})
                    comment = _format_jira_comment(triage)
                    client.add_comment(ticket["id"], comment)
                    client.transition_issue(ticket["id"], "In Progress")
                    client.update_labels(ticket["id"], add=["TRIAGED"])
                except Exception as e:
                    logger.error("Failed to write back to Jira for %s: %s", ticket["id"], e)

def _format_jira_comment(triage: dict) -> str:
    actions = "\n".join(f"* {a}" for a in triage.get("recommended_actions", []))
    return (
        f"*[AIOps Triage Result]*\n"
        f"* Category: {triage.get('category')}\n"
        f"* Severity: {triage.get('severity')}\n"
        f"* Root Cause Hypothesis: {triage.get('root_cause_hypothesis')}\n"
        f"* Recommended Actions:\n{actions}\n"
        f"* Requires Approval: {triage.get('requires_approval')}"
    )

def start_scheduler(app):
    global _job
    from app.config import load_config
    cfg = load_config()
    interval = cfg["agent"].get("polling_interval_seconds", 30)
    _job = _scheduler.add_job(
        _poll_and_triage, "interval", seconds=interval, args=[app],
        id="triage_poll", replace_existing=True,
    )
    if not _scheduler.running:
        _scheduler.start()
    logger.info("Triage scheduler started (interval=%ds)", interval)

def pause_agent():
    if _scheduler.get_job("triage_poll"):
        _scheduler.pause_job("triage_poll")

def resume_agent():
    if _scheduler.get_job("triage_poll"):
        _scheduler.resume_job("triage_poll")
