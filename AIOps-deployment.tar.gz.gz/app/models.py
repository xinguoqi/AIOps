from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from datetime import datetime

db = SQLAlchemy()

class User(UserMixin, db.Model):
    __tablename__ = "users"
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)
    role = db.Column(db.String(16), nullable=False, default="viewer")  # viewer|operator|admin

class AuditLog(db.Model):
    __tablename__ = "audit_log"
    id = db.Column(db.Integer, primary_key=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    actor = db.Column(db.String(64), nullable=False)
    action = db.Column(db.String(128), nullable=False)
    ticket_id = db.Column(db.String(32))
    detail = db.Column(db.Text)
    outcome = db.Column(db.String(32))
    prompt_version = db.Column(db.String(16))

class ApprovalRequest(db.Model):
    __tablename__ = "approval_requests"
    id = db.Column(db.Integer, primary_key=True)
    ticket_id = db.Column(db.String(32), nullable=False)
    action_type = db.Column(db.String(64), nullable=False)
    action_detail = db.Column(db.Text)
    status = db.Column(db.String(32), default="PENDING_APPROVAL")  # PENDING_APPROVAL|APPROVED|REJECTED
    requested_at = db.Column(db.DateTime, default=datetime.utcnow)
    decided_at = db.Column(db.DateTime)
    decided_by = db.Column(db.String(64))
    reason = db.Column(db.Text)
