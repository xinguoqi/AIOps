from functools import wraps
from flask import abort
from flask_login import current_user

ROLE_HIERARCHY = {"viewer": 0, "operator": 1, "admin": 2}

def role_required(min_role: str):
    def decorator(f):
        @wraps(f)
        def wrapped(*args, **kwargs):
            if not current_user.is_authenticated:
                abort(401)
            if ROLE_HIERARCHY.get(current_user.role, -1) < ROLE_HIERARCHY.get(min_role, 99):
                abort(403)
            return f(*args, **kwargs)
        return wrapped
    return decorator
