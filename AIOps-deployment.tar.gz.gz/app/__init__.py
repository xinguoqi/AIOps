from flask import Flask
from flask_login import LoginManager
from werkzeug.security import generate_password_hash

from app.config import AppConfig
from app.models import db, User

login_manager = LoginManager()


def _auto_index_knowledge_base():
    """Index the default Excel file if the knowledge base is empty."""
    import os
    default_file = "data/History tickets sample for AIOPS.xlsx"
    if not os.path.exists(default_file):
        return
    try:
        from app.rag.store import collection_stats, index_excel
        stats = collection_stats()
        if stats["total"] == 0:
            count = index_excel(default_file, source_name="History tickets sample for AIOPS.xlsx")
            import logging
            logging.getLogger(__name__).info("Auto-indexed %d records from default KB file", count)
    except Exception as e:
        import logging
        logging.getLogger(__name__).warning("Auto-index failed: %s", e)


def create_app():
    app = Flask(__name__, template_folder="templates")
    app.config.from_object(AppConfig)

    db.init_app(app)
    login_manager.init_app(app)
    login_manager.login_view = "auth.login"

    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))

    with app.app_context():
        db.create_all()
        _seed_users()
        _auto_index_knowledge_base()

    # Blueprints
    from app.auth.routes import auth_bp
    from app.jira.routes import jira_bp
    from app.main.routes import main_bp
    from app.api.routes import api_bp
    from app.rag.routes import rag_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(jira_bp)
    app.register_blueprint(main_bp)
    app.register_blueprint(api_bp)
    app.register_blueprint(rag_bp)

    # Start background scheduler (skip in testing)
    if not app.config.get("TESTING"):
        from app.agent.scheduler import start_scheduler
        start_scheduler(app)

    return app

def _seed_users():
    defaults = [
        ("admin", "admin123", "admin"),
        ("operator", "op123", "operator"),
        ("viewer", "view123", "viewer"),
    ]
    for username, password, role in defaults:
        if not User.query.filter_by(username=username).first():
            db.session.add(User(
                username=username,
                password_hash=generate_password_hash(password),
                role=role,
            ))
    db.session.commit()
