#!/bin/sh
set -e

# Ensure runtime directories exist (volumes may be empty on first run)
mkdir -p /app/logs /app/data /app/instance

echo "[entrypoint] Starting AIOps application..."

# Run with gunicorn: 2 workers, bind to all interfaces
exec gunicorn \
  --workers 2 \
  --threads 2 \
  --bind 0.0.0.0:5000 \
  --timeout 120 \
  --access-logfile - \
  --error-logfile - \
  --log-level info \
  "run:app"
