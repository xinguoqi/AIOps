#!/bin/bash
# AIOps + Jira Deployment Script
set -euo pipefail

APP_PORT="${APP_PORT:-5000}"
JIRA_PORT="${JIRA_PORT:-8081}"
HEALTH_URL="http://localhost:${APP_PORT}/api/health"
MAX_WAIT=120  # seconds to wait for app health

# ── Colors ────────────────────────────────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
info()  { echo -e "${GREEN}[deploy]${NC} $*"; }
warn()  { echo -e "${YELLOW}[warn]${NC}  $*"; }
error() { echo -e "${RED}[error]${NC} $*" >&2; exit 1; }

# ── Prerequisites ─────────────────────────────────────────────────────────────
command -v docker >/dev/null 2>&1 || error "Docker not found. Install Docker 24+."
docker compose version >/dev/null 2>&1 || error "Docker Compose v2 not found."

DOCKER_MIN=24
DOCKER_VER=$(docker version --format '{{.Server.Version}}' 2>/dev/null | cut -d. -f1)
[ "${DOCKER_VER:-0}" -ge "$DOCKER_MIN" ] || warn "Docker ${DOCKER_VER} detected; recommend 24+."

# ── Environment ───────────────────────────────────────────────────────────────
if [ ! -f .env ]; then
  if [ -f .env.example ]; then
    cp .env.example .env
    warn ".env not found — copied from .env.example. Edit it before production use."
  else
    error ".env file missing and no .env.example to copy from."
  fi
fi

# Warn about placeholder values
if grep -qE "change-me|your-.*-here|your-jira" .env 2>/dev/null; then
  warn "Placeholder values detected in .env — update SECRET_KEY, DASHSCOPE_API_KEY, JIRA_PAT."
fi

# ── Build & Start ─────────────────────────────────────────────────────────────
info "Building and starting services..."
docker compose pull --ignore-pull-failures 2>/dev/null || true
docker compose up -d --build

# ── Wait for AIOps health ─────────────────────────────────────────────────────
info "Waiting for AIOps app to be healthy (max ${MAX_WAIT}s)..."
elapsed=0
until curl -sf "$HEALTH_URL" >/dev/null 2>&1; do
  if [ "$elapsed" -ge "$MAX_WAIT" ]; then
    warn "App did not become healthy in ${MAX_WAIT}s. Check logs: docker compose logs aiops-app"
    break
  fi
  sleep 5
  elapsed=$((elapsed + 5))
  echo -n "."
done
echo ""

# ── Status ────────────────────────────────────────────────────────────────────
info "Service status:"
docker compose ps

echo ""
info "AIOps UI:    http://localhost:${APP_PORT}  (admin/admin123)"
info "Jira:        http://localhost:${JIRA_PORT} (complete setup wizard on first run)"
info ""
info "Default credentials — change after first login:"
echo "  admin   / admin123  (full access)"
echo "  operator/ op123     (triage + approve)"
echo "  viewer  / view123   (read-only)"
echo ""
info "Useful commands:"
echo "  docker compose logs -f aiops-app   # tail app logs"
echo "  docker compose restart aiops-app   # reload after config.yaml changes"
echo "  docker compose down                # stop all services"
echo "  docker compose down -v             # stop and wipe all data (destructive)"
