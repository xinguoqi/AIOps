from app import create_app
import logging
import os

logging.basicConfig(
    level=logging.INFO,
    format='{"time":"%(asctime)s","level":"%(levelname)s","name":"%(name)s","msg":"%(message)s"}',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("logs/aiops.log"),
    ]
)

app = create_app()

if __name__ == "__main__":
    app.run(debug=True, use_reloader=False)
