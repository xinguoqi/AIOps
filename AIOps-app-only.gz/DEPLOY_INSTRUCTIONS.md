# AIOps Deployment Instructions for Alicloud ECS

## Prerequisites

- Alicloud ECS instance running Linux (Ubuntu 20.04+ or CentOS 8+)
- Docker 24+ installed
- Docker Compose v2 installed
- At least 4GB RAM, 20GB disk space
- Ports 5000 and 8081 available

## Quick Start

1. **Upload this package to your ECS instance:**
   ```bash
   scp aiops-deployment-*.tar.gz user@your-ecs-ip:/opt/
   ```

2. **Extract on the server:**
   ```bash
   cd /opt
   tar -xzf aiops-deployment-*.tar.gz
   cd aiops-deploy-temp
   ```

3. **Configure environment:**
   ```bash
   cp .env.example .env
   nano .env  # Edit with your actual values
   ```

   **Required settings:**
   - `SECRET_KEY` - Generate with: `python3 -c "import secrets; print(secrets.token_hex(32))"`
   - `DASHSCOPE_API_KEY` - Your Alibaba DashScope API key
   - `QWEN_MODEL` - LLM model name (default: qwen3-max-2026-01-23)
   - `JIRA_PAT` - Your Jira Personal Access Token

   **Optional Langfuse settings (for observability):**
   - `OBSERVABILITY_ENABLED=true`
   - `LANGFUSE_PUBLIC_KEY` - Your Langfuse public key
   - `LANGFUSE_SECRET_KEY` - Your Langfuse secret key
   - `LANGFUSE_HOST` - Your Langfuse server URL

4. **Deploy:**
   ```bash
   chmod +x deploy.sh
   ./deploy.sh
   ```

5. **Access the application:**
   - AIOps UI: http://your-ecs-ip:5000
   - Jira: http://your-ecs-ip:8081

   Default credentials:
   - admin / admin123 (full access)
   - operator / op123 (triage + approve)
   - viewer / view123 (read-only)

## Post-Deployment

### Check Status
```bash
docker compose ps
docker compose logs -f aiops-app
```

### Restart Services
```bash
docker compose restart aiops-app
```

### Stop Services
```bash
docker compose down
```

### Update Configuration
Edit `config.yaml` and restart:
```bash
nano config.yaml
docker compose restart aiops-app
```

### View Logs
```bash
docker compose logs -f aiops-app
docker compose logs -f jira-software
```

### Backup Data
```bash
docker compose exec aiops-app tar -czf /tmp/backup.tar.gz /app/instance /app/data
docker cp aiops-app:/tmp/backup.tar.gz ./backup-$(date +%Y%m%d).tar.gz
```

## Firewall Configuration

If using Alicloud Security Groups, allow inbound traffic:
- Port 5000 (AIOps application)
- Port 8081 (Jira)
- Port 3000 (Langfuse, if using external observability)

## Troubleshooting

### App won't start
```bash
docker compose logs aiops-app
# Check for missing environment variables or API key issues
```

### Langfuse traces not appearing
1. Verify `OBSERVABILITY_ENABLED=true` in .env
2. Check Langfuse credentials are correct
3. Ensure Langfuse server is accessible from ECS
4. Check logs: `docker compose logs aiops-app | grep -i langfuse`

### Jira connection issues
1. Complete Jira setup wizard first (http://your-ecs-ip:8081)
2. Create a Personal Access Token in Jira
3. Update `JIRA_PAT` in .env
4. Restart: `docker compose restart aiops-app`

### Out of memory
Increase JVM heap in .env:
```
JIRA_JVM_MIN=4096m
JIRA_JVM_MAX=8192m
```

## Updating the Application

1. Stop services: `docker compose down`
2. Upload new deployment package
3. Extract and replace files
4. Restart: `./deploy.sh`

## Security Recommendations

1. Change all default passwords immediately
2. Use strong SECRET_KEY (32+ random bytes)
3. Keep API keys in .env, never commit to git
4. Use HTTPS in production (add nginx reverse proxy)
5. Regularly update Docker images: `docker compose pull`
6. Backup data regularly

## Support

For issues, check:
- Application logs: `docker compose logs aiops-app`
- Jira logs: `docker compose logs jira-software`
- System resources: `docker stats`
