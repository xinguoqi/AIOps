#!/bin/bash
# Update only AIOps app without touching other services
set -euo pipefail

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

info() { echo -e "${GREEN}[update]${NC} $*"; }
warn() { echo -e "${YELLOW}[warn]${NC} $*"; }

info "Updating AIOps application only (preserving Jira and other services)..."

# Backup current app code
info "Creating backup..."
BACKUP_DIR="backup-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$BACKUP_DIR"
cp -r app/ "$BACKUP_DIR/" 2>/dev/null || true
cp config.yaml "$BACKUP_DIR/" 2>/dev/null || true
info "Backup saved to: $BACKUP_DIR"

# Stop only aiops-app service
info "Stopping aiops-app service..."
docker compose stop aiops-app

# Rebuild only aiops-app service
info "Rebuilding aiops-app image..."
docker compose build aiops-app

# Start only aiops-app service
info "Starting aiops-app service..."
docker compose up -d aiops-app

# Wait for health check
info "Waiting for aiops-app to be healthy..."
sleep 5
for i in {1..12}; do
    if curl -sf http://localhost:${APP_PORT:-5000}/api/health >/dev/null 2>&1; then
        info "✓ AIOps app is healthy!"
        break
    fi
    echo -n "."
    sleep 5
done
echo ""

# Show status
info "Service status:"
docker compose ps

info "✓ Update complete!"
info "Other services (Jira, Langfuse, PostgreSQL) were not affected."
info ""
info "Check logs: docker compose logs -f aiops-app"
