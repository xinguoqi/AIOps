# AIOps Update Guide - App Only (Without Rebuilding Other Services)

## Quick Update Commands

### Option 1: Using the Update Script (Recommended)

```bash
chmod +x update_app_only.sh
./update_app_only.sh
```

### Option 2: Manual Docker Compose Commands

```bash
# Stop only aiops-app
docker compose stop aiops-app

# Rebuild only aiops-app
docker compose build aiops-app

# Start only aiops-app
docker compose up -d aiops-app

# Check status
docker compose ps
docker compose logs -f aiops-app
```

### Option 3: Update Without Rebuild (Code Changes Only)

If you only changed Python code (no requirements.txt changes):

```bash
# Stop the app
docker compose stop aiops-app

# Copy new code into the running container's volume
# OR restart with volume mount (see below)

# Start the app
docker compose start aiops-app
```

## Detailed Update Scenarios

### Scenario 1: Update Application Code Only

**When:** You've updated Python files in `app/` directory

```bash
# Method A: Rebuild the image
docker compose stop aiops-app
docker compose build --no-cache aiops-app
docker compose up -d aiops-app

# Method B: Use volume mount (for development)
# Edit docker-compose.yml to add volume mount:
# volumes:
#   - ./app:/app/app:ro
# Then just restart:
docker compose restart aiops-app
```

### Scenario 2: Update Configuration Only

**When:** You've changed `config.yaml` or `.env`

```bash
# For config.yaml (already mounted as volume)
nano config.yaml
docker compose restart aiops-app

# For .env changes
nano .env
docker compose up -d aiops-app  # Recreates container with new env
```

### Scenario 3: Update Dependencies

**When:** You've changed `requirements.txt`

```bash
# Must rebuild the image
docker compose stop aiops-app
docker compose build --no-cache aiops-app
docker compose up -d aiops-app
```

### Scenario 4: Update from New Deployment Package

**When:** You have a new `aiops-deployment-*.tar.gz`

```bash
# Backup current version
tar -czf backup-$(date +%Y%m%d).tar.gz app/ config.yaml

# Extract new package (overwrites app/ directory)
tar -xzf aiops-deployment-NEW.tar.gz

# Preserve your .env file (don't overwrite with .env.example)
# Your .env should already exist

# Update only aiops-app
docker compose stop aiops-app
docker compose build aiops-app
docker compose up -d aiops-app
```

## What Gets Updated vs What Stays

### ✅ Updated (aiops-app only)
- Application code (`app/` directory)
- Python dependencies
- Configuration (`config.yaml`)
- Environment variables (`.env`)

### ⛔ NOT Updated (preserved)
- Jira service (keeps running)
- Jira PostgreSQL database (keeps running)
- Langfuse service (if running separately)
- All data volumes:
  - `aiops-db` (SQLite database)
  - `aiops-data` (knowledge base)
  - `aiops-logs` (application logs)
  - `jira-data` (Jira data)
  - `jira-pg-data` (Jira database)

## Verification After Update

```bash
# 1. Check all services are running
docker compose ps
# Expected: aiops-app, jira-software, jira-postgresql all "Up"

# 2. Check aiops-app logs
docker compose logs --tail=50 aiops-app

# 3. Test health endpoint
curl http://localhost:5000/api/health

# 4. Verify Langfuse integration (if enabled)
docker compose logs aiops-app | grep -i "langfuse initialized successfully"

# 5. Check other services weren't affected
docker compose logs --tail=10 jira-software
docker compose logs --tail=10 jira-postgresql
```

## Rollback if Update Fails

```bash
# Stop the new version
docker compose stop aiops-app

# Restore from backup
rm -rf app/
tar -xzf backup-YYYYMMDD-HHMMSS.tar.gz

# Rebuild with old code
docker compose build aiops-app
docker compose up -d aiops-app
```

## Advanced: Zero-Downtime Update

For production environments where you can't afford downtime:

```bash
# 1. Scale up to 2 instances (requires load balancer)
docker compose up -d --scale aiops-app=2

# 2. Update code
# ... extract new package ...

# 3. Rebuild image
docker compose build aiops-app

# 4. Rolling restart
docker compose up -d --no-deps --scale aiops-app=2 aiops-app

# 5. Scale back to 1
docker compose up -d --scale aiops-app=1
```

## Common Issues

### Issue: "Service is not running"
```bash
# Check what's wrong
docker compose ps
docker compose logs aiops-app

# Force recreate
docker compose up -d --force-recreate aiops-app
```

### Issue: "Port already in use"
```bash
# Another container might be using the port
docker ps -a | grep 5000

# Stop the conflicting container
docker stop <container-id>

# Or change port in .env
nano .env  # Change APP_PORT=5001
docker compose up -d aiops-app
```

### Issue: "Image build failed"
```bash
# Clean build cache
docker builder prune -a

# Rebuild without cache
docker compose build --no-cache aiops-app
```

### Issue: "New code not reflected"
```bash
# Make sure you're rebuilding
docker compose build --no-cache aiops-app

# Check if old image is cached
docker images | grep aiops

# Remove old images
docker image prune -a
```

## Best Practices

1. **Always backup before updating**
   ```bash
   tar -czf backup-$(date +%Y%m%d).tar.gz app/ config.yaml .env
   ```

2. **Test in staging first** (if possible)
   ```bash
   # Use different ports for staging
   APP_PORT=5001 docker compose up -d aiops-app
   ```

3. **Check logs after update**
   ```bash
   docker compose logs -f aiops-app
   ```

4. **Verify Langfuse integration**
   ```bash
   # Should see initialization message
   docker compose logs aiops-app | grep Langfuse
   ```

5. **Monitor resource usage**
   ```bash
   docker stats aiops-app
   ```

## Update Checklist

- [ ] Backup current version
- [ ] Extract new deployment package
- [ ] Preserve `.env` file (don't overwrite)
- [ ] Stop aiops-app service only
- [ ] Rebuild aiops-app image
- [ ] Start aiops-app service
- [ ] Check logs for errors
- [ ] Test health endpoint
- [ ] Verify Langfuse traces (if enabled)
- [ ] Confirm other services still running
- [ ] Test application functionality

## Quick Reference

```bash
# Update app only (preserves Jira, Langfuse, etc.)
docker compose stop aiops-app
docker compose build aiops-app
docker compose up -d aiops-app

# Check status
docker compose ps

# View logs
docker compose logs -f aiops-app

# Restart if needed
docker compose restart aiops-app

# Rollback
docker compose stop aiops-app
# ... restore backup ...
docker compose build aiops-app
docker compose up -d aiops-app
```

---

**Key Point:** Using `docker compose` commands with the service name (`aiops-app`) ensures only that service is affected. Other services (Jira, PostgreSQL, Langfuse) continue running without interruption.
