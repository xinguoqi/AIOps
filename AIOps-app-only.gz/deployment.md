# AIOps Cloud Deployment Guide

## Prerequisites

- Docker 24+ and Docker Compose v2
- 6 GB RAM minimum (Jira alone needs 4 GB)
- Alibaba DashScope API key (for LLM/Qwen)

---

## Quick Start

### 1. Configure environment

```bash
cp .env.example .env
# Edit .env — set SECRET_KEY, DASHSCOPE_API_KEY, JIRA_PAT at minimum
```

### 2. Build and start all services

```bash
docker compose up -d --build
```

Services started:
| Service | URL | Notes |
|---|---|---|
| AIOps App | http://localhost:5000 | Flask + Gunicorn |
| Jira Software | http://localhost:8080 | First run needs license setup |
| Jira Postgres | internal only | Port not exposed |

### 3. First-time Jira setup

1. Open http://localhost:8080 and complete the Jira setup wizard
2. Create a project with key `AIOP` (or update `config.yaml` → `jira.project_key`)
3. Generate a Personal Access Token in Jira → Profile → Personal Access Tokens
4. Set `JIRA_PAT=<your-token>` in `.env` and restart: `docker compose restart aiops-app`

### 4. Log in to AIOps

Open http://localhost:5000 and use the default credentials:

| Username | Password | Role |
|---|---|---|
| admin | admin123 | Full access |
| operator | op123 | Triage + approve |
| viewer | view123 | Read-only |

> Change these passwords via the admin UI after first login.

---

## Common Operations

```bash
# View logs
docker compose logs -f aiops-app

# Restart only the app (after config.yaml changes)
docker compose restart aiops-app

# Stop everything
docker compose down

# Stop and wipe all data (destructive)
docker compose down -v
```

---

## Cloud Deployment

The stack is provider-agnostic. Any host that runs Docker Compose works.

### AWS EC2 / Azure VM / GCP Compute Engine

```bash
# On the VM:
git clone <your-repo> aiops && cd aiops
cp .env.example .env && nano .env   # fill in secrets
docker compose up -d --build
```

Open the VM's firewall for ports `5000` and `8080`.

### AWS ECS / Azure ACI / GCP Cloud Run

For managed container platforms, build and push the app image separately:

```bash
# Build and tag
docker build -t your-registry/aiops-app:latest .

# Push
docker push your-registry/aiops-app:latest
```

Then deploy `aiops-app` to your managed platform and run Jira + Postgres on a VM or managed DB.

### Environment variables in cloud

Never commit `.env` to source control. Use your cloud provider's secrets service:
- AWS: Secrets Manager or Parameter Store
- Azure: Key Vault
- GCP: Secret Manager

---

## Configuration

Edit `config.yaml` to change agent behavior without rebuilding:

```yaml
agent:
  polling_interval_seconds: 30   # how often to poll Jira
jira:
  project_key: AIOP              # Jira project to monitor
  url: http://jira-software:8080 # internal Docker hostname
llm:
  model: qwen3-max-2026-01-23
  temperature: 0.2
```

The file is volume-mounted, so changes take effect after `docker compose restart aiops-app`.

---

## Volumes

| Volume | Contents |
|---|---|
| `aiops-db` | SQLite database (users, audit, approvals) |
| `aiops-data` | Mock Jira store JSON |
| `aiops-logs` | Application logs |
| `jira-pg-data` | Jira's Postgres data |
| `jira-data` | Jira application data |

Back these up before any destructive operations.
