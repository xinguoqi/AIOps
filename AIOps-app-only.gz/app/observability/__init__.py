"""
Observability module initialization.

This module configures Langfuse tracing when OBSERVABILITY_ENABLED=true.
"""
import os
import logging

logger = logging.getLogger(__name__)

def init_langfuse():
    """
    Initialize Langfuse client if observability is enabled.
    This must be called early in the application lifecycle.
    """
    if os.getenv("OBSERVABILITY_ENABLED", "false").lower() != "true":
        logger.info("Observability disabled (OBSERVABILITY_ENABLED != true)")
        return

    try:
        from langfuse import Langfuse

        public_key = os.getenv("LANGFUSE_PUBLIC_KEY")
        secret_key = os.getenv("LANGFUSE_SECRET_KEY")
        host = os.getenv("LANGFUSE_HOST", "http://localhost:3000")

        if not public_key or not secret_key:
            logger.warning("Langfuse keys not configured - tracing disabled")
            return

        # Initialize the global Langfuse client
        # This is required for the @observe decorator to work
        langfuse_client = Langfuse(
            public_key=public_key,
            secret_key=secret_key,
            host=host
        )

        logger.info(f"Langfuse initialized successfully (host: {host})")

        # Test connection
        try:
            test_trace = langfuse_client.trace(name="app_startup")
            test_trace.update(metadata={"status": "initialized"})
            langfuse_client.flush()
            logger.info("Langfuse connection verified")
        except Exception as e:
            logger.warning(f"Langfuse connection test failed: {e}")

    except ImportError:
        logger.warning("langfuse package not installed - tracing disabled")
    except Exception as e:
        logger.error(f"Failed to initialize Langfuse: {e}", exc_info=True)
