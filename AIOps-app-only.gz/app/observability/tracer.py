import os
import logging

logger = logging.getLogger(__name__)


def is_tracing_enabled() -> bool:
    enabled = os.getenv("OBSERVABILITY_ENABLED", "false").lower() == "true"
    if enabled:
        logger.info("Tracing is ENABLED (OBSERVABILITY_ENABLED=true)")
    return enabled


def observe(name: str = None):
    """
    Decorator factory. When OBSERVABILITY_ENABLED=true and langfuse is installed,
    wraps the function with langfuse.decorators.observe. Otherwise returns the function unchanged.
    """
    def decorator(fn):
        if not is_tracing_enabled():
            logger.debug(f"Tracing disabled for {fn.__name__}")
            return fn
        try:
            from langfuse.decorators import observe as lf_observe
            logger.info(f"Wrapping {fn.__name__} with Langfuse @observe decorator (name={name or fn.__name__})")
            return lf_observe(name=name or fn.__name__)(fn)
        except ImportError:
            logger.warning("langfuse not installed — tracing disabled")
            return fn
        except Exception as e:
            logger.error(f"Failed to wrap {fn.__name__} with @observe: {e}")
            return fn
    return decorator
